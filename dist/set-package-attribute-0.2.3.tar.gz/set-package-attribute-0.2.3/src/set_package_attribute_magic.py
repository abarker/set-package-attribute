"""

This is just a shortcut module which only requires an import.  It then calls
`set_package_attribute.init()` with the default argument values.

"""

import set_package_attribute

set_package_attribute.init()

